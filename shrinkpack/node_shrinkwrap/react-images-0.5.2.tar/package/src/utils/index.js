import bindFunctions from './bindFunctions';
import canUseDom from './canUseDom';
import deepMerge from './deepMerge';

module.exports = {
	bindFunctions,
	canUseDom,
	deepMerge,
};
