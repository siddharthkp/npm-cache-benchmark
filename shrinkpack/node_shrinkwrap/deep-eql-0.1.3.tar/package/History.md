
0.1.3 / 2013-10-10 
==================

 * pkg: update type-detect version
 * index,test: conditional require in test bootstrap

0.1.2 / 2013-09-18 
==================

 * bug: [fix] misnamed variable from code migration (reference error)

0.1.1 / 2013-09-18 
==================

 * bug: [fix] last key of deep object ignored

0.1.0 / 2013-09-18 
==================

 * tests: add iterable
 * docs: readme
 * makefile: [ci] update cov handling
 * testing: [env] use karma for phantom
 * add tests (uncompleted)
 * add library
 * add dependencies
 * "Initial commit"
