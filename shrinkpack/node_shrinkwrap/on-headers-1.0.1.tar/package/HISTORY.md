1.0.1 / 2015-09-29
==================

  * perf: enable strict mode

1.0.0 / 2014-08-10
==================

  * Honor `res.statusCode` change in `listener`
  * Move to `jshttp` orgainzation
  * Prevent `arguments`-related de-opt

0.0.0 / 2014-05-13
==================

  * Initial implementation
