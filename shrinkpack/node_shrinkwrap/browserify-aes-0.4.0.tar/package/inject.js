module.exports = function (crypto, exports) {
  exports = exports || {};
  var ciphers = require('./encrypter')(crypto);
  exports.createCipher = ciphers.createCipher;
  exports.createCipheriv = ciphers.createCipheriv;
  var deciphers = require('./decrypter')(crypto);
  exports.createDecipher = deciphers.createDecipher;
  exports.createDecipheriv = deciphers.createDecipheriv;
  var modes = require('./modes');
  function listCiphers () {
    return Object.keys(modes);
  }
  exports.listCiphers = listCiphers;
};

