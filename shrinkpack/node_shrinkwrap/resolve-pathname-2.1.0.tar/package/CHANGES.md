## [HEAD]

- **Breakage:** Changed default `from` path to `/`
- Added LOTS more test cases from node's `url.parse` test suite

[HEAD]: https://github.com/mjackson/resolve-pathname/compare/latest...HEAD
