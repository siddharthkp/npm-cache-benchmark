# react-fontawesome examples

## Setup

```bash
npm install
npm start
open index.html
```
