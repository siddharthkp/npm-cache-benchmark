import ascending from "./ascending";

export default function(series) {
  return ascending(series).reverse();
}
