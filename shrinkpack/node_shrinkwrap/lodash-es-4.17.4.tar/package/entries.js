export { default } from './toPairs.js'
