export { default as clamp } from './clamp.js';
export { default as inRange } from './inRange.js';
export { default as random } from './random.js';
export { default } from './number.default.js';
