module.exports = require('./lib/type');
