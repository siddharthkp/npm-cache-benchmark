module.exports = require('./lib/no-important.js');
