# Examples of using aphrodite

Run: `npm install && npm run examples`, then open `http://localhost:4114` and `http://localhost:4114/ssr`.
