'use strict';

module.exports = function (value) { return (value !== value); } //jslint: ignore
