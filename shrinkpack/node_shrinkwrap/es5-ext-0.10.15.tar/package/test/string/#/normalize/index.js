'use strict';

module.exports = require('./shim');
