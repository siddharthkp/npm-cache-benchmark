'use strict';

module.exports = function (x) {
	return function () { return x; };
};
