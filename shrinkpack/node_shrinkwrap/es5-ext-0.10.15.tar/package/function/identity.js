'use strict';

module.exports = function (x) { return x; };
