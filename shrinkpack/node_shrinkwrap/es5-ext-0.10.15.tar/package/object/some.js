'use strict';

module.exports = require('./_iterate')('some', false);
