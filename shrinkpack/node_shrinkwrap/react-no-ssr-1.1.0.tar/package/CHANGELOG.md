# Change Log

### v1.1.0
2016-04-09

* Update React for v15.0.0

### v1.0.1
2016-02-19

* remove jsdom from the dependencies.

### v1.0.0
2016-02-19

* Initial Release
