module.exports = require('./src/ScrollLock');
