<a name="0.3.0"></a>
# [0.3.0](https://github.com/BerkeleyTrue/redux-epic/compare/v0.2.0...v0.3.0) (2017-05-05)


### Features

* **combineEpics:** Adds new combineEpics ([946febf](https://github.com/BerkeleyTrue/redux-epic/commit/946febf))


### BREAKING CHANGES

* **combineEpics:** Removes ofType method from actions stream



