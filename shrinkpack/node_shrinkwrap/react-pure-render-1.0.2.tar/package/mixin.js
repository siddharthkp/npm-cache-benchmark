'use strict';

exports.__esModule = true;

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { 'default': obj }; }

var _function = require('./function');

var _function2 = _interopRequireDefault(_function);

exports['default'] = {
  shouldComponentUpdate: _function2['default']
};
module.exports = exports['default'];