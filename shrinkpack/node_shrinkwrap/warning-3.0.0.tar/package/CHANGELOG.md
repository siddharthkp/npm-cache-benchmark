v2.0.0 - July 11, 2015
---------------------

- [1a33d40fa1](https://github.com/r3dm/warning/commit/1a33d40fa1) add browserify.js

v1.0.2 - May 30, 2015
--------------------------------------

- [2ac6962](https://github.com/r3dm/warning/commit/2ac6962263) fix return args in replace
