export default function(x) {
  return x === null ? NaN : +x;
}
